#pragma once
#define VERSION_MAJOR 2
#define VERSION_MINOR 3
#define VERSION_PATCH 0
#define VERSION_BUILD 1111

#define stringify(a) stringify_(a)
#define stringify_(a) #a

